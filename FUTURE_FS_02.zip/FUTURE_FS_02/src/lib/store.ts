import { Lead, Activity, FollowUp, Note, PipelineStage, LeadSource } from './types';

const KEYS = { leads: 'nf_leads', activities: 'nf_activities', followups: 'nf_followups', notes: 'nf_notes', auth: 'nf_auth' };

function load<T>(key: string, fallback: T[]): T[] {
  try { return JSON.parse(localStorage.getItem(key) || '[]'); } catch { return fallback; }
}
function save<T>(key: string, data: T[]) { localStorage.setItem(key, JSON.stringify(data)); }

export const uid = () => crypto.randomUUID();

// Auth
export const login = (email: string, password: string): boolean => {
  if (email === 'admin@nexusflow.io' && password === 'admin123') {
    localStorage.setItem(KEYS.auth, JSON.stringify({ email, loggedIn: true, loginAt: new Date().toISOString() }));
    return true;
  }
  return false;
};
export const logout = () => localStorage.removeItem(KEYS.auth);
export const isLoggedIn = () => {
  try { return JSON.parse(localStorage.getItem(KEYS.auth) || '{}').loggedIn === true; } catch { return false; }
};

// Leads
export const getLeads = (): Lead[] => load<Lead>(KEYS.leads, []);
export const getLead = (id: string): Lead | undefined => getLeads().find(l => l.id === id);
export const saveLead = (lead: Lead) => {
  const leads = getLeads();
  const idx = leads.findIndex(l => l.id === lead.id);
  if (idx >= 0) leads[idx] = { ...lead, updatedAt: new Date().toISOString() };
  else leads.push(lead);
  save(KEYS.leads, leads);
};
export const deleteLead = (id: string) => {
  save(KEYS.leads, getLeads().filter(l => l.id !== id));
  save(KEYS.activities, getActivities().filter(a => a.leadId !== id));
  save(KEYS.followups, getFollowUps().filter(f => f.leadId !== id));
  save(KEYS.notes, getNotes().filter(n => n.leadId !== id));
};
export const updateLeadStage = (id: string, stage: PipelineStage) => {
  const lead = getLead(id);
  if (!lead) return;
  const oldStage = lead.stage;
  lead.stage = stage;
  lead.updatedAt = new Date().toISOString();
  // Update health score based on stage
  if (stage === 'Won') lead.healthScore = 100;
  else if (stage === 'Lost') lead.healthScore = 0;
  else if (stage === 'Negotiation') lead.healthScore = Math.max(lead.healthScore, 70);
  else if (stage === 'Contacted') lead.healthScore = Math.max(lead.healthScore, 40);
  saveLead(lead);
  addActivity({ id: uid(), leadId: id, type: 'stage_change', description: `Stage changed from ${oldStage} to ${stage}`, timestamp: new Date().toISOString() });
};

// Activities
export const getActivities = (): Activity[] => load<Activity>(KEYS.activities, []);
export const getLeadActivities = (leadId: string): Activity[] => getActivities().filter(a => a.leadId === leadId).sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime());
export const addActivity = (activity: Activity) => { const all = getActivities(); all.push(activity); save(KEYS.activities, all); };

// Follow-ups
export const getFollowUps = (): FollowUp[] => load<FollowUp>(KEYS.followups, []);
export const getLeadFollowUps = (leadId: string): FollowUp[] => getFollowUps().filter(f => f.leadId === leadId);
export const saveFollowUp = (f: FollowUp) => {
  const all = getFollowUps();
  const idx = all.findIndex(x => x.id === f.id);
  if (idx >= 0) all[idx] = f; else all.push(f);
  save(KEYS.followups, all);
};
export const deleteFollowUp = (id: string) => save(KEYS.followups, getFollowUps().filter(f => f.id !== id));

// Notes
export const getNotes = (): Note[] => load<Note>(KEYS.notes, []);
export const getLeadNotes = (leadId: string): Note[] => getNotes().filter(n => n.leadId === leadId).sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
export const addNote = (note: Note) => { const all = getNotes(); all.push(note); save(KEYS.notes, all); };
export const deleteNote = (id: string) => save(KEYS.notes, getNotes().filter(n => n.id !== id));

// Seed data
export const seedData = () => {
  if (getLeads().length > 0) return;
  const now = new Date();
  const sources: LeadSource[] = ['Website', 'LinkedIn', 'Referral', 'Ads'];
  const stages: PipelineStage[] = ['Prospect', 'Contacted', 'Negotiation', 'Won', 'Lost'];
  const names = ['Sarah Chen', 'Marcus Rivera', 'Aisha Patel', 'David Kim', 'Emma Thompson', 'James Wilson', 'Priya Sharma', 'Lucas Brown', 'Olivia Davis', 'Noah Martinez'];
  const companies = ['TechNova Inc', 'Quantum Labs', 'CloudBase', 'DataStream', 'NeuralPath', 'CyberVault', 'FlowStack', 'PixelForge', 'CodeHive', 'SynthWave'];

  names.forEach((name, i) => {
    const id = uid();
    const stage = stages[i % 5];
    const lead: Lead = {
      id, name, email: `${name.toLowerCase().replace(' ', '.')}@${companies[i].toLowerCase().replace(/\s/g, '')}.com`,
      phone: `+1-555-${String(1000 + i * 111).slice(0, 4)}`, company: companies[i],
      source: sources[i % 4], value: [5000, 12000, 25000, 50000, 8000, 35000, 18000, 42000, 15000, 28000][i],
      stage, notes: '', healthScore: [30, 55, 75, 100, 10, 85, 60, 90, 45, 70][i],
      priority: (['Low', 'Medium', 'High', 'Critical'] as const)[i % 4],
      relationshipStrength: [20, 45, 70, 95, 15, 80, 50, 88, 35, 65][i],
      createdAt: new Date(now.getTime() - (30 - i * 3) * 86400000).toISOString(),
      updatedAt: new Date(now.getTime() - i * 86400000).toISOString(),
    };
    saveLead(lead);
    addActivity({ id: uid(), leadId: id, type: 'created', description: `Lead created from ${lead.source}`, timestamp: lead.createdAt });
    if (i % 2 === 0) addActivity({ id: uid(), leadId: id, type: 'email', description: 'Introduction email sent', timestamp: new Date(now.getTime() - (25 - i * 2) * 86400000).toISOString() });
    if (i % 3 === 0) addActivity({ id: uid(), leadId: id, type: 'meeting', description: 'Discovery call scheduled', timestamp: new Date(now.getTime() - (20 - i) * 86400000).toISOString() });
    if (i < 4) {
      saveFollowUp({ id: uid(), leadId: id, title: `Follow up with ${name}`, date: new Date(now.getTime() + (i + 1) * 86400000).toISOString(), completed: false, notes: 'Check on proposal status' });
    }
  });
};
