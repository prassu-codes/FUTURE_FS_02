export type LeadSource = 'Website' | 'LinkedIn' | 'Referral' | 'Ads';
export type PipelineStage = 'Prospect' | 'Contacted' | 'Negotiation' | 'Won' | 'Lost';

export interface Lead {
  id: string;
  name: string;
  email: string;
  phone: string;
  company: string;
  source: LeadSource;
  value: number;
  stage: PipelineStage;
  notes: string;
  healthScore: number; // 0-100
  priority: 'Low' | 'Medium' | 'High' | 'Critical';
  relationshipStrength: number; // 0-100
  createdAt: string;
  updatedAt: string;
}

export interface Activity {
  id: string;
  leadId: string;
  type: 'created' | 'email' | 'call' | 'meeting' | 'note' | 'stage_change' | 'follow_up';
  description: string;
  timestamp: string;
}

export interface FollowUp {
  id: string;
  leadId: string;
  title: string;
  date: string;
  completed: boolean;
  notes: string;
}

export interface Note {
  id: string;
  leadId: string;
  content: string;
  createdAt: string;
}
