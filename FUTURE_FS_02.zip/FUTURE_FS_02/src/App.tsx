import { useState, useEffect } from 'react';
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Route, Routes } from "react-router-dom";
import { TooltipProvider } from "@/components/ui/tooltip";
import { isLoggedIn, seedData } from '@/lib/store';
import LoginPage from './pages/LoginPage';
import AppShell from './components/AppShell';
import DashboardPage from './pages/DashboardPage';
import PipelinePage from './pages/PipelinePage';
import LeadsPage from './pages/LeadsPage';
import LeadDetailPage from './pages/LeadDetailPage';
import AnalyticsPage from './pages/AnalyticsPage';
import FollowUpsPage from './pages/FollowUpsPage';
import NotFound from './pages/NotFound';

const queryClient = new QueryClient();

const App = () => {
  const [authed, setAuthed] = useState(isLoggedIn);

  useEffect(() => { seedData(); }, []);

  if (!authed) return <LoginPage onLogin={() => setAuthed(true)} />;

  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <BrowserRouter>
          <AppShell onLogout={() => setAuthed(false)}>
            <Routes>
              <Route path="/" element={<DashboardPage />} />
              <Route path="/pipeline" element={<PipelinePage />} />
              <Route path="/leads" element={<LeadsPage />} />
              <Route path="/leads/:id" element={<LeadDetailPage />} />
              <Route path="/analytics" element={<AnalyticsPage />} />
              <Route path="/follow-ups" element={<FollowUpsPage />} />
              <Route path="*" element={<NotFound />} />
            </Routes>
          </AppShell>
        </BrowserRouter>
      </TooltipProvider>
    </QueryClientProvider>
  );
};

export default App;
