import { useState, useMemo } from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Check, Clock, Calendar, Trash2, Plus } from 'lucide-react';
import { getFollowUps, getLeads, saveFollowUp, deleteFollowUp, uid } from '@/lib/store';
import type { FollowUp } from '@/lib/types';

const FollowUpsPage = () => {
  const [followUps, setFollowUps] = useState(() => getFollowUps());
  const [filter, setFilter] = useState<'all' | 'pending' | 'completed'>('pending');
  const leads = useMemo(() => getLeads(), []);

  const refresh = () => setFollowUps(getFollowUps());

  const getLeadName = (leadId: string) => leads.find(l => l.id === leadId)?.name || 'Unknown';

  const filtered = followUps
    .filter(f => filter === 'all' ? true : filter === 'pending' ? !f.completed : f.completed)
    .sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime());

  const overdue = filtered.filter(f => !f.completed && new Date(f.date) < new Date());
  const upcoming = filtered.filter(f => !f.completed && new Date(f.date) >= new Date());
  const completed = filtered.filter(f => f.completed);

  const toggleComplete = (id: string) => {
    const fu = followUps.find(f => f.id === id);
    if (!fu) return;
    saveFollowUp({ ...fu, completed: !fu.completed });
    refresh();
  };

  const handleDelete = (id: string) => {
    deleteFollowUp(id);
    refresh();
  };

  const renderGroup = (title: string, items: FollowUp[], color: string) => {
    if (items.length === 0) return null;
    return (
      <div className="space-y-3">
        <h3 className={`text-sm font-semibold uppercase tracking-wider ${color}`}>{title} ({items.length})</h3>
        {items.map(fu => (
          <motion.div key={fu.id} layout initial={{ opacity: 0 }} animate={{ opacity: 1 }} className={`glass-card-hover p-4 flex items-start gap-3 ${fu.completed ? 'opacity-50' : ''}`}>
            <button onClick={() => toggleComplete(fu.id)} className={`w-5 h-5 rounded border-2 flex items-center justify-center mt-0.5 transition-colors ${fu.completed ? 'bg-success border-success' : 'border-border hover:border-primary'}`}>
              {fu.completed && <Check className="w-3 h-3 text-primary-foreground" />}
            </button>
            <div className="flex-1 min-w-0">
              <p className={`font-medium text-sm ${fu.completed ? 'line-through' : ''}`}>{fu.title}</p>
              <Link to={`/leads/${fu.leadId}`} className="text-xs text-primary hover:underline">{getLeadName(fu.leadId)}</Link>
              <p className="text-xs text-muted-foreground flex items-center gap-1 mt-1"><Calendar className="w-3 h-3" />{new Date(fu.date).toLocaleDateString()}</p>
              {fu.notes && <p className="text-xs text-muted-foreground mt-1">{fu.notes}</p>}
            </div>
            <button onClick={() => handleDelete(fu.id)} className="p-1.5 rounded hover:bg-destructive/10 text-muted-foreground hover:text-destructive">
              <Trash2 className="w-4 h-4" />
            </button>
          </motion.div>
        ))}
      </div>
    );
  };

  return (
    <div className="space-y-6 max-w-3xl mx-auto">
      <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }}>
        <h1 className="text-3xl font-display font-bold">Follow-up Intelligence</h1>
        <p className="text-muted-foreground mt-1">Stay on top of your relationship touchpoints</p>
      </motion.div>

      <div className="flex gap-1 bg-card/40 backdrop-blur-sm rounded-lg p-1">
        {(['pending', 'all', 'completed'] as const).map(f => (
          <button key={f} onClick={() => setFilter(f)} className={`flex-1 py-2.5 rounded-md text-sm font-medium transition-all capitalize ${filter === f ? 'bg-primary text-primary-foreground' : 'text-muted-foreground hover:text-foreground'}`}>
            {f}
          </button>
        ))}
      </div>

      <div className="space-y-6">
        {renderGroup('Overdue', overdue, 'text-destructive')}
        {renderGroup('Upcoming', upcoming, 'text-warning')}
        {renderGroup('Completed', completed, 'text-success')}
        {filtered.length === 0 && (
          <div className="text-center py-16 text-muted-foreground">
            <Clock className="w-12 h-12 mx-auto mb-3 opacity-30" />
            <p>No follow-ups to show</p>
          </div>
        )}
      </div>
    </div>
  );
};

export default FollowUpsPage;
