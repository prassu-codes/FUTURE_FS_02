import { useState, useMemo } from 'react';
import { useParams, Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { ArrowLeft, Mail, Phone, Building2, Globe, DollarSign, Calendar, Plus, Trash2, Check, Clock, Heart, Shield, MessageSquare } from 'lucide-react';
import { getLead, getLeadActivities, getLeadFollowUps, getLeadNotes, saveLead, saveFollowUp, addNote, deleteFollowUp, deleteNote, addActivity, uid, getLeads } from '@/lib/store';
import type { Lead, PipelineStage } from '@/lib/types';

const STAGES: PipelineStage[] = ['Prospect', 'Contacted', 'Negotiation', 'Won', 'Lost'];

const LeadDetailPage = () => {
  const { id } = useParams<{ id: string }>();
  const [lead, setLead] = useState(() => getLead(id || ''));
  const [activities, setActivities] = useState(() => getLeadActivities(id || ''));
  const [followUps, setFollowUps] = useState(() => getLeadFollowUps(id || ''));
  const [notes, setNotes] = useState(() => getLeadNotes(id || ''));
  const [activeTab, setActiveTab] = useState<'timeline' | 'followups' | 'notes'>('timeline');
  const [newNote, setNewNote] = useState('');
  const [newFollowUp, setNewFollowUp] = useState({ title: '', date: '', notes: '' });
  const [showFollowUpForm, setShowFollowUpForm] = useState(false);

  if (!lead || !id) return (
    <div className="text-center py-20">
      <p className="text-muted-foreground text-lg">Lead not found</p>
      <Link to="/leads" className="text-primary hover:underline mt-2 inline-block">← Back to leads</Link>
    </div>
  );

  const refresh = () => {
    setLead(getLead(id));
    setActivities(getLeadActivities(id));
    setFollowUps(getLeadFollowUps(id));
    setNotes(getLeadNotes(id));
  };

  const handleStageChange = (stage: PipelineStage) => {
    const updated = { ...lead, stage, updatedAt: new Date().toISOString() };
    saveLead(updated as Lead);
    addActivity({ id: uid(), leadId: id, type: 'stage_change', description: `Stage changed to ${stage}`, timestamp: new Date().toISOString() });
    refresh();
  };

  const handleAddNote = () => {
    if (!newNote.trim()) return;
    addNote({ id: uid(), leadId: id, content: newNote.trim(), createdAt: new Date().toISOString() });
    addActivity({ id: uid(), leadId: id, type: 'note', description: `Note added: "${newNote.trim().slice(0, 50)}..."`, timestamp: new Date().toISOString() });
    setNewNote('');
    refresh();
  };

  const handleAddFollowUp = () => {
    if (!newFollowUp.title || !newFollowUp.date) return;
    saveFollowUp({ id: uid(), leadId: id, title: newFollowUp.title, date: new Date(newFollowUp.date).toISOString(), completed: false, notes: newFollowUp.notes });
    addActivity({ id: uid(), leadId: id, type: 'follow_up', description: `Follow-up scheduled: "${newFollowUp.title}"`, timestamp: new Date().toISOString() });
    setNewFollowUp({ title: '', date: '', notes: '' });
    setShowFollowUpForm(false);
    refresh();
  };

  const toggleFollowUp = (fId: string) => {
    const fu = followUps.find(f => f.id === fId);
    if (!fu) return;
    saveFollowUp({ ...fu, completed: !fu.completed });
    refresh();
  };

  const activityIcon = (type: string) => {
    const map: Record<string, string> = { created: '🆕', email: '📧', call: '📞', meeting: '📅', note: '📝', stage_change: '🔄', follow_up: '⏰' };
    return map[type] || '📌';
  };

  const strengthLabel = lead.relationshipStrength >= 70 ? 'Strong' : lead.relationshipStrength >= 40 ? 'Growing' : 'New';
  const strengthColor = lead.relationshipStrength >= 70 ? 'text-success' : lead.relationshipStrength >= 40 ? 'text-warning' : 'text-info';

  const inputClass = "w-full px-3 py-2.5 rounded-lg bg-secondary border border-border focus:border-primary focus:outline-none focus:ring-1 focus:ring-primary transition-colors text-foreground text-sm";
  const tabs = [
    { key: 'timeline' as const, label: 'Timeline', count: activities.length },
    { key: 'followups' as const, label: 'Follow-ups', count: followUps.length },
    { key: 'notes' as const, label: 'Notes', count: notes.length },
  ];

  return (
    <div className="max-w-5xl mx-auto space-y-6">
      <Link to="/leads" className="inline-flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground transition-colors">
        <ArrowLeft className="w-4 h-4" /> Back to Leads
      </Link>

      {/* Header Card */}
      <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="glass-card p-6">
        <div className="flex flex-col md:flex-row gap-6">
          <div className="w-20 h-20 rounded-2xl bg-gradient-to-br from-primary/40 to-accent/40 flex items-center justify-center text-2xl font-bold font-display">
            {lead.name.split(' ').map(n => n[0]).join('')}
          </div>
          <div className="flex-1">
            <h1 className="text-2xl font-display font-bold">{lead.name}</h1>
            <p className="text-muted-foreground flex items-center gap-2 mt-1"><Building2 className="w-4 h-4" />{lead.company}</p>
            <div className="flex flex-wrap gap-4 mt-3 text-sm text-muted-foreground">
              <span className="flex items-center gap-1.5"><Mail className="w-4 h-4" />{lead.email}</span>
              <span className="flex items-center gap-1.5"><Phone className="w-4 h-4" />{lead.phone}</span>
              <span className="flex items-center gap-1.5"><Globe className="w-4 h-4" />{lead.source}</span>
              <span className="flex items-center gap-1.5"><DollarSign className="w-4 h-4" />${lead.value.toLocaleString()}</span>
            </div>
          </div>

          {/* Scores */}
          <div className="flex flex-row md:flex-col gap-4">
            <div className="glass-card p-3 text-center min-w-[100px]">
              <Shield className="w-5 h-5 mx-auto mb-1 text-primary" />
              <p className="text-lg font-bold">{lead.healthScore}%</p>
              <p className="text-[10px] text-muted-foreground">Health Score</p>
            </div>
            <div className="glass-card p-3 text-center min-w-[100px]">
              <Heart className={`w-5 h-5 mx-auto mb-1 ${strengthColor}`} />
              <p className="text-lg font-bold">{lead.relationshipStrength}%</p>
              <p className="text-[10px] text-muted-foreground">{strengthLabel}</p>
            </div>
          </div>
        </div>

        {/* Stage Progress */}
        <div className="mt-6">
          <p className="text-xs text-muted-foreground mb-2">Pipeline Stage</p>
          <div className="flex gap-2">
            {STAGES.map(stage => (
              <button
                key={stage}
                onClick={() => handleStageChange(stage)}
                className={`flex-1 py-2 rounded-lg text-xs font-semibold transition-all ${
                  lead.stage === stage
                    ? 'bg-primary text-primary-foreground glow-primary'
                    : 'bg-secondary text-muted-foreground hover:text-foreground hover:bg-secondary/80'
                }`}
              >
                {stage}
              </button>
            ))}
          </div>
        </div>
      </motion.div>

      {/* Tabs */}
      <div className="flex gap-1 bg-card/40 backdrop-blur-sm rounded-lg p-1">
        {tabs.map(tab => (
          <button
            key={tab.key}
            onClick={() => setActiveTab(tab.key)}
            className={`flex-1 py-2.5 rounded-md text-sm font-medium transition-all ${
              activeTab === tab.key ? 'bg-primary text-primary-foreground' : 'text-muted-foreground hover:text-foreground'
            }`}
          >
            {tab.label} ({tab.count})
          </button>
        ))}
      </div>

      {/* Tab Content */}
      <motion.div key={activeTab} initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} className="glass-card p-6">
        {activeTab === 'timeline' && (
          <div className="space-y-4">
            <h3 className="font-display font-semibold text-lg">Activity Timeline</h3>
            {activities.length === 0 && <p className="text-muted-foreground text-sm">No activity yet</p>}
            <div className="relative">
              {activities.map((act, i) => (
                <div key={act.id} className="flex gap-4 pb-6 last:pb-0">
                  <div className="flex flex-col items-center">
                    <span className="text-xl">{activityIcon(act.type)}</span>
                    {i < activities.length - 1 && <div className="w-px flex-1 bg-border mt-2" />}
                  </div>
                  <div>
                    <p className="text-sm">{act.description}</p>
                    <p className="text-xs text-muted-foreground mt-0.5">{new Date(act.timestamp).toLocaleString()}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {activeTab === 'followups' && (
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="font-display font-semibold text-lg">Follow-ups</h3>
              <button onClick={() => setShowFollowUpForm(!showFollowUpForm)} className="flex items-center gap-1 text-sm text-primary hover:underline">
                <Plus className="w-4 h-4" /> Add
              </button>
            </div>
            {showFollowUpForm && (
              <div className="glass-card p-4 space-y-3">
                <input placeholder="Follow-up title" value={newFollowUp.title} onChange={e => setNewFollowUp({ ...newFollowUp, title: e.target.value })} className={inputClass} />
                <input type="date" value={newFollowUp.date} onChange={e => setNewFollowUp({ ...newFollowUp, date: e.target.value })} className={inputClass} />
                <textarea rows={2} placeholder="Notes (optional)" value={newFollowUp.notes} onChange={e => setNewFollowUp({ ...newFollowUp, notes: e.target.value })} className={inputClass} />
                <button onClick={handleAddFollowUp} className="px-4 py-2 rounded-lg bg-primary text-primary-foreground text-sm font-semibold hover:opacity-90">Save</button>
              </div>
            )}
            {followUps.map(fu => (
              <div key={fu.id} className={`flex items-start gap-3 p-3 rounded-lg transition-colors ${fu.completed ? 'opacity-50' : 'hover:bg-secondary/50'}`}>
                <button onClick={() => toggleFollowUp(fu.id)} className={`w-5 h-5 rounded border-2 flex items-center justify-center mt-0.5 transition-colors ${fu.completed ? 'bg-success border-success' : 'border-border hover:border-primary'}`}>
                  {fu.completed && <Check className="w-3 h-3 text-primary-foreground" />}
                </button>
                <div className="flex-1">
                  <p className={`text-sm font-medium ${fu.completed ? 'line-through' : ''}`}>{fu.title}</p>
                  <p className="text-xs text-muted-foreground flex items-center gap-1 mt-0.5"><Calendar className="w-3 h-3" />{new Date(fu.date).toLocaleDateString()}</p>
                  {fu.notes && <p className="text-xs text-muted-foreground mt-1">{fu.notes}</p>}
                </div>
                <button onClick={() => { deleteFollowUp(fu.id); refresh(); }} className="p-1.5 rounded hover:bg-destructive/10 text-muted-foreground hover:text-destructive">
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            ))}
            {followUps.length === 0 && !showFollowUpForm && <p className="text-muted-foreground text-sm">No follow-ups scheduled</p>}
          </div>
        )}

        {activeTab === 'notes' && (
          <div className="space-y-4">
            <h3 className="font-display font-semibold text-lg">Notes</h3>
            <div className="flex gap-2">
              <input value={newNote} onChange={e => setNewNote(e.target.value)} placeholder="Add a note..." className={`${inputClass} flex-1`} onKeyDown={e => e.key === 'Enter' && handleAddNote()} />
              <button onClick={handleAddNote} className="px-4 py-2 rounded-lg bg-primary text-primary-foreground text-sm font-semibold hover:opacity-90">Add</button>
            </div>
            {notes.map(note => (
              <div key={note.id} className="flex items-start gap-3 p-3 rounded-lg hover:bg-secondary/50 transition-colors">
                <MessageSquare className="w-4 h-4 text-muted-foreground mt-0.5" />
                <div className="flex-1">
                  <p className="text-sm">{note.content}</p>
                  <p className="text-xs text-muted-foreground mt-1">{new Date(note.createdAt).toLocaleString()}</p>
                </div>
                <button onClick={() => { deleteNote(note.id); refresh(); }} className="p-1.5 rounded hover:bg-destructive/10 text-muted-foreground hover:text-destructive">
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            ))}
            {notes.length === 0 && <p className="text-muted-foreground text-sm">No notes yet</p>}
          </div>
        )}
      </motion.div>
    </div>
  );
};

export default LeadDetailPage;
