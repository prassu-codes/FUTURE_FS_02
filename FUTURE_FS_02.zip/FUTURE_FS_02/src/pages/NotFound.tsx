import { Link } from "react-router-dom";

const NotFound = () => (
  <div className="text-center py-20">
    <h1 className="text-6xl font-display font-bold gradient-text">404</h1>
    <p className="text-muted-foreground mt-3 text-lg">Page not found</p>
    <Link to="/" className="inline-block mt-6 px-6 py-3 rounded-lg bg-primary text-primary-foreground font-semibold hover:opacity-90 transition-opacity">
      Back to Dashboard
    </Link>
  </div>
);

export default NotFound;
