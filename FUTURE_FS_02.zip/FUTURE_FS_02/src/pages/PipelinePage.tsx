import { useState, useMemo, useCallback } from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { getLeads, updateLeadStage, getLead } from '@/lib/store';
import type { PipelineStage, Lead } from '@/lib/types';
import { GripVertical, DollarSign, Building2, ArrowRight } from 'lucide-react';

const STAGES: PipelineStage[] = ['Prospect', 'Contacted', 'Negotiation', 'Won', 'Lost'];
const STAGE_COLORS: Record<PipelineStage, string> = {
  Prospect: 'border-t-info', Contacted: 'border-t-primary', Negotiation: 'border-t-warning', Won: 'border-t-success', Lost: 'border-t-destructive',
};
const STAGE_BG: Record<PipelineStage, string> = {
  Prospect: 'bg-info/10', Contacted: 'bg-primary/10', Negotiation: 'bg-warning/10', Won: 'bg-success/10', Lost: 'bg-destructive/10',
};

const PriorityBadge = ({ priority }: { priority: Lead['priority'] }) => {
  const colors: Record<string, string> = { Critical: 'bg-destructive/20 text-destructive', High: 'bg-warning/20 text-warning', Medium: 'bg-info/20 text-info', Low: 'bg-muted text-muted-foreground' };
  return <span className={`text-[10px] px-2 py-0.5 rounded-full font-semibold ${colors[priority]}`}>{priority}</span>;
};

const PipelinePage = () => {
  const [leads, setLeads] = useState(() => getLeads());
  const [draggedLead, setDraggedLead] = useState<string | null>(null);
  const [dropTarget, setDropTarget] = useState<PipelineStage | null>(null);

  const grouped = useMemo(() => {
    const map: Record<PipelineStage, Lead[]> = { Prospect: [], Contacted: [], Negotiation: [], Won: [], Lost: [] };
    leads.forEach(l => map[l.stage]?.push(l));
    return map;
  }, [leads]);

  const handleDragStart = (e: React.DragEvent<HTMLDivElement>, leadId: string) => {
    e.dataTransfer.setData('text/plain', leadId);
    setDraggedLead(leadId);
  };

  const handleDragOver = (e: React.DragEvent<HTMLDivElement>, stage: PipelineStage) => {
    e.preventDefault();
    setDropTarget(stage);
  };

  const handleDrop = (e: React.DragEvent<HTMLDivElement>, stage: PipelineStage) => {
    e.preventDefault();
    const leadId = e.dataTransfer.getData('text/plain');
    if (leadId) {
      updateLeadStage(leadId, stage);
      setLeads(getLeads());
    }
    setDraggedLead(null);
    setDropTarget(null);
  };

  const stageValue = (stage: PipelineStage) => grouped[stage].reduce((s, l) => s + l.value, 0);

  return (
    <div className="space-y-6">
      <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }}>
        <h1 className="text-3xl font-display font-bold">Smart Pipeline</h1>
        <p className="text-muted-foreground mt-1">Drag leads between stages to update their status</p>
      </motion.div>

      <div className="flex gap-4 overflow-x-auto pb-4 scrollbar-thin">
        {STAGES.map((stage, si) => (
          <motion.div
            key={stage}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: si * 0.08 }}
            className="flex-shrink-0 w-72"
          >
            <div className={`glass-card border-t-4 ${STAGE_COLORS[stage]} overflow-hidden`}>
              <div className="p-4 border-b border-border/50">
                <div className="flex items-center justify-between">
                  <h3 className="font-display font-semibold">{stage}</h3>
                  <span className={`text-xs px-2 py-1 rounded-full ${STAGE_BG[stage]} font-semibold`}>{grouped[stage].length}</span>
                </div>
                <p className="text-xs text-muted-foreground mt-1">${stageValue(stage).toLocaleString()} total</p>
              </div>

              <div
                className={`p-3 min-h-[300px] space-y-3 transition-colors ${dropTarget === stage ? 'bg-primary/5' : ''}`}
                onDragOver={e => handleDragOver(e, stage)}
                onDragLeave={() => setDropTarget(null)}
                onDrop={e => handleDrop(e, stage)}
              >
                {grouped[stage].map(lead => (
                  <div
                    key={lead.id}
                    draggable
                    onDragStart={e => handleDragStart(e, lead.id)}
                    onDragEnd={() => { setDraggedLead(null); setDropTarget(null); }}
                    className={`glass-card-hover p-4 cursor-grab active:cursor-grabbing ${draggedLead === lead.id ? 'opacity-50' : ''}`}
                  >
                    <div className="flex items-start justify-between mb-2">
                      <div className="flex items-center gap-2">
                        <GripVertical className="w-4 h-4 text-muted-foreground/50" />
                        <span className="font-medium text-sm">{lead.name}</span>
                      </div>
                      <PriorityBadge priority={lead.priority} />
                    </div>
                    <div className="flex items-center gap-2 text-xs text-muted-foreground mb-2">
                      <Building2 className="w-3 h-3" />{lead.company}
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-xs font-semibold text-accent flex items-center gap-1">
                        <DollarSign className="w-3 h-3" />{lead.value.toLocaleString()}
                      </span>
                      <Link to={`/leads/${lead.id}`} className="text-xs text-primary hover:underline flex items-center gap-1">
                        View <ArrowRight className="w-3 h-3" />
                      </Link>
                    </div>
                    <div className="mt-2 w-full h-1 bg-secondary rounded-full overflow-hidden">
                      <div className={`h-full rounded-full ${lead.healthScore >= 70 ? 'bg-success' : lead.healthScore >= 40 ? 'bg-warning' : 'bg-destructive'}`} style={{ width: `${lead.healthScore}%` }} />
                    </div>
                  </div>
                ))}
                {grouped[stage].length === 0 && (
                  <div className="text-center py-8 text-muted-foreground text-sm border-2 border-dashed border-border/30 rounded-lg">
                    Drop leads here
                  </div>
                )}
              </div>
            </div>
          </motion.div>
        ))}
      </div>
    </div>
  );
};

export default PipelinePage;
