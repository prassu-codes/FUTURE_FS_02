import { useMemo } from 'react';
import { motion } from 'framer-motion';
import { Link } from 'react-router-dom';
import { Users, TrendingUp, DollarSign, Clock, ArrowUpRight, Zap, Activity } from 'lucide-react';
import { getLeads, getFollowUps, getActivities } from '@/lib/store';
import type { Lead } from '@/lib/types';

const StatCard = ({ icon: Icon, label, value, sub, color, delay }: { icon: any; label: string; value: string; sub?: string; color: string; delay: number }) => (
  <motion.div
    initial={{ opacity: 0, y: 20 }}
    animate={{ opacity: 1, y: 0 }}
    transition={{ delay, duration: 0.4 }}
    className="glass-card-hover p-6 group"
  >
    <div className="flex items-start justify-between">
      <div className={`w-12 h-12 rounded-xl flex items-center justify-center ${color}`}>
        <Icon className="w-6 h-6" />
      </div>
      <ArrowUpRight className="w-5 h-5 text-muted-foreground opacity-0 group-hover:opacity-100 transition-opacity" />
    </div>
    <p className="text-2xl font-display font-bold mt-4">{value}</p>
    <p className="text-sm text-muted-foreground">{label}</p>
    {sub && <p className="text-xs text-success mt-1">{sub}</p>}
  </motion.div>
);

const HealthBar = ({ score }: { score: number }) => {
  const color = score >= 70 ? 'bg-success' : score >= 40 ? 'bg-warning' : 'bg-destructive';
  return (
    <div className="w-full h-1.5 bg-secondary rounded-full overflow-hidden">
      <div className={`h-full ${color} rounded-full transition-all`} style={{ width: `${score}%` }} />
    </div>
  );
};

const DashboardPage = () => {
  const leads = useMemo(() => getLeads(), []);
  const followUps = useMemo(() => getFollowUps().filter(f => !f.completed), []);
  const activities = useMemo(() => getActivities().sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime()).slice(0, 8), []);

  const totalValue = leads.reduce((s, l) => s + l.value, 0);
  const wonLeads = leads.filter(l => l.stage === 'Won');
  const conversionRate = leads.length > 0 ? Math.round((wonLeads.length / leads.length) * 100) : 0;

  const topLeads = [...leads].sort((a, b) => b.healthScore - a.healthScore).slice(0, 5);

  const activityIcon = (type: string) => {
    const map: Record<string, string> = { created: '🆕', email: '📧', call: '📞', meeting: '📅', note: '📝', stage_change: '🔄', follow_up: '⏰' };
    return map[type] || '📌';
  };

  return (
    <div className="space-y-8 max-w-7xl mx-auto">
      <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }}>
        <h1 className="text-3xl font-display font-bold">Command Center</h1>
        <p className="text-muted-foreground mt-1">Your relationship intelligence overview</p>
      </motion.div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
        <StatCard icon={Users} label="Total Leads" value={String(leads.length)} color="bg-primary/20 text-primary" delay={0} />
        <StatCard icon={TrendingUp} label="Conversion Rate" value={`${conversionRate}%`} sub={`${wonLeads.length} won`} color="bg-success/20 text-success" delay={0.1} />
        <StatCard icon={DollarSign} label="Pipeline Value" value={`$${(totalValue / 1000).toFixed(0)}k`} color="bg-accent/20 text-accent" delay={0.2} />
        <StatCard icon={Clock} label="Pending Follow-ups" value={String(followUps.length)} color="bg-warning/20 text-warning" delay={0.3} />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Top Leads by Health */}
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.4 }} className="lg:col-span-2 glass-card p-6">
          <h2 className="font-display font-semibold text-lg mb-4 flex items-center gap-2">
            <Zap className="w-5 h-5 text-primary" /> Lead Health Monitor
          </h2>
          <div className="space-y-4">
            {topLeads.map(lead => (
              <Link key={lead.id} to={`/leads/${lead.id}`} className="flex items-center gap-4 p-3 rounded-lg hover:bg-secondary/50 transition-colors group">
                <div className="w-10 h-10 rounded-full bg-gradient-to-br from-primary/30 to-accent/30 flex items-center justify-center text-sm font-bold">
                  {lead.name.split(' ').map(n => n[0]).join('')}
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center justify-between mb-1">
                    <span className="font-medium text-sm truncate">{lead.name}</span>
                    <span className={`text-xs font-semibold ${lead.healthScore >= 70 ? 'text-success' : lead.healthScore >= 40 ? 'text-warning' : 'text-destructive'}`}>
                      {lead.healthScore}%
                    </span>
                  </div>
                  <HealthBar score={lead.healthScore} />
                  <p className="text-xs text-muted-foreground mt-1">{lead.company} · ${lead.value.toLocaleString()}</p>
                </div>
              </Link>
            ))}
          </div>
        </motion.div>

        {/* Recent Activity */}
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.5 }} className="glass-card p-6">
          <h2 className="font-display font-semibold text-lg mb-4 flex items-center gap-2">
            <Activity className="w-5 h-5 text-accent" /> Recent Activity
          </h2>
          <div className="space-y-3">
            {activities.map(act => (
              <div key={act.id} className="flex items-start gap-3 text-sm">
                <span className="text-lg mt-0.5">{activityIcon(act.type)}</span>
                <div>
                  <p className="text-foreground/90">{act.description}</p>
                  <p className="text-xs text-muted-foreground">{new Date(act.timestamp).toLocaleDateString()}</p>
                </div>
              </div>
            ))}
            {activities.length === 0 && <p className="text-muted-foreground text-sm">No activity yet</p>}
          </div>
        </motion.div>
      </div>
    </div>
  );
};

export default DashboardPage;
