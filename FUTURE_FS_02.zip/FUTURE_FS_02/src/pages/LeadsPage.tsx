import { useState, useMemo } from 'react';
import { Link, useSearchParams } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import { Plus, Search, Filter, Trash2, Edit3, X, Building2, Mail, Phone, Globe } from 'lucide-react';
import { getLeads, saveLead, deleteLead, addActivity, uid } from '@/lib/store';
import type { Lead, LeadSource, PipelineStage } from '@/lib/types';

const SOURCES: LeadSource[] = ['Website', 'LinkedIn', 'Referral', 'Ads'];
const STAGES: PipelineStage[] = ['Prospect', 'Contacted', 'Negotiation', 'Won', 'Lost'];
const PRIORITIES: Lead['priority'][] = ['Low', 'Medium', 'High', 'Critical'];

const emptyLead = (): Partial<Lead> => ({ name: '', email: '', phone: '', company: '', source: 'Website', value: 0, notes: '', stage: 'Prospect', priority: 'Medium' });

const LeadsPage = () => {
  const [searchParams] = useSearchParams();
  const [leads, setLeads] = useState(() => getLeads());
  const [search, setSearch] = useState('');
  const [stageFilter, setStageFilter] = useState<string>('All');
  const [sourceFilter, setSourceFilter] = useState<string>('All');
  const [showForm, setShowForm] = useState(false);
  const [editLead, setEditLead] = useState<Partial<Lead> | null>(null);
  const [showFilters, setShowFilters] = useState(false);

  const filtered = useMemo(() => {
    return leads.filter(l => {
      const q = search.toLowerCase();
      const matchSearch = !q || l.name.toLowerCase().includes(q) || l.company.toLowerCase().includes(q) || l.email.toLowerCase().includes(q);
      const matchStage = stageFilter === 'All' || l.stage === stageFilter;
      const matchSource = sourceFilter === 'All' || l.source === sourceFilter;
      return matchSearch && matchStage && matchSource;
    });
  }, [leads, search, stageFilter, sourceFilter]);

  const openCreate = () => { setEditLead(emptyLead()); setShowForm(true); };
  const openEdit = (lead: Lead) => { setEditLead({ ...lead }); setShowForm(true); };
  const closeForm = () => { setEditLead(null); setShowForm(false); };

  const handleSave = () => {
    if (!editLead?.name || !editLead?.email) return;
    const isNew = !editLead.id;
    const lead: Lead = {
      id: editLead.id || uid(),
      name: editLead.name,
      email: editLead.email,
      phone: editLead.phone || '',
      company: editLead.company || '',
      source: editLead.source as LeadSource || 'Website',
      value: editLead.value || 0,
      stage: editLead.stage as PipelineStage || 'Prospect',
      notes: editLead.notes || '',
      healthScore: editLead.healthScore || 30,
      priority: editLead.priority || 'Medium',
      relationshipStrength: editLead.relationshipStrength || 20,
      createdAt: editLead.createdAt || new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    saveLead(lead);
    if (isNew) addActivity({ id: uid(), leadId: lead.id, type: 'created', description: `Lead "${lead.name}" created`, timestamp: new Date().toISOString() });
    setLeads(getLeads());
    closeForm();
  };

  const handleDelete = (id: string) => {
    if (!confirm('Delete this lead?')) return;
    deleteLead(id);
    setLeads(getLeads());
  };

  const inputClass = "w-full px-3 py-2.5 rounded-lg bg-secondary border border-border focus:border-primary focus:outline-none focus:ring-1 focus:ring-primary transition-colors text-foreground text-sm";

  return (
    <div className="space-y-6 max-w-7xl mx-auto">
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }}>
          <h1 className="text-3xl font-display font-bold">Leads</h1>
          <p className="text-muted-foreground mt-1">{filtered.length} of {leads.length} leads</p>
        </motion.div>
        <button onClick={openCreate} className="flex items-center gap-2 px-5 py-2.5 rounded-lg bg-gradient-to-r from-primary to-accent text-primary-foreground font-semibold text-sm hover:opacity-90 transition-opacity">
          <Plus className="w-4 h-4" /> Add Lead
        </button>
      </div>

      {/* Search & Filters */}
      <div className="flex flex-col sm:flex-row gap-3">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <input value={search} onChange={e => setSearch(e.target.value)} placeholder="Search by name, company, email..." className={`${inputClass} pl-10`} />
        </div>
        <button onClick={() => setShowFilters(!showFilters)} className="flex items-center gap-2 px-4 py-2.5 rounded-lg bg-secondary text-sm text-muted-foreground hover:text-foreground transition-colors">
          <Filter className="w-4 h-4" /> Filters
        </button>
      </div>

      <AnimatePresence>
        {showFilters && (
          <motion.div initial={{ height: 0, opacity: 0 }} animate={{ height: 'auto', opacity: 1 }} exit={{ height: 0, opacity: 0 }} className="flex flex-wrap gap-3 overflow-hidden">
            <select value={stageFilter} onChange={e => setStageFilter(e.target.value)} className={`${inputClass} w-auto`}>
              <option value="All">All Stages</option>
              {STAGES.map(s => <option key={s} value={s}>{s}</option>)}
            </select>
            <select value={sourceFilter} onChange={e => setSourceFilter(e.target.value)} className={`${inputClass} w-auto`}>
              <option value="All">All Sources</option>
              {SOURCES.map(s => <option key={s} value={s}>{s}</option>)}
            </select>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Leads Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
        <AnimatePresence mode="popLayout">
          {filtered.map((lead, i) => (
            <motion.div
              key={lead.id}
              layout
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              transition={{ delay: i * 0.03 }}
              className="glass-card-hover p-5"
            >
              <div className="flex items-start justify-between mb-3">
                <Link to={`/leads/${lead.id}`} className="flex items-center gap-3 hover:opacity-80 transition-opacity">
                  <div className="w-11 h-11 rounded-full bg-gradient-to-br from-primary/40 to-accent/40 flex items-center justify-center text-sm font-bold">
                    {lead.name.split(' ').map(n => n[0]).join('')}
                  </div>
                  <div>
                    <p className="font-semibold">{lead.name}</p>
                    <p className="text-xs text-muted-foreground flex items-center gap-1"><Building2 className="w-3 h-3" />{lead.company}</p>
                  </div>
                </Link>
                <div className="flex gap-1">
                  <button onClick={() => openEdit(lead)} className="p-2 rounded-lg hover:bg-secondary text-muted-foreground hover:text-foreground transition-colors"><Edit3 className="w-4 h-4" /></button>
                  <button onClick={() => handleDelete(lead.id)} className="p-2 rounded-lg hover:bg-destructive/10 text-muted-foreground hover:text-destructive transition-colors"><Trash2 className="w-4 h-4" /></button>
                </div>
              </div>

              <div className="space-y-1.5 text-xs text-muted-foreground mb-3">
                <p className="flex items-center gap-2"><Mail className="w-3 h-3" />{lead.email}</p>
                <p className="flex items-center gap-2"><Phone className="w-3 h-3" />{lead.phone}</p>
                <p className="flex items-center gap-2"><Globe className="w-3 h-3" />{lead.source}</p>
              </div>

              <div className="flex items-center justify-between">
                <span className={`text-xs px-2.5 py-1 rounded-full font-semibold ${
                  lead.stage === 'Won' ? 'bg-success/20 text-success' :
                  lead.stage === 'Lost' ? 'bg-destructive/20 text-destructive' :
                  lead.stage === 'Negotiation' ? 'bg-warning/20 text-warning' :
                  lead.stage === 'Contacted' ? 'bg-primary/20 text-primary' :
                  'bg-info/20 text-info'
                }`}>{lead.stage}</span>
                <span className="text-sm font-bold text-accent">${lead.value.toLocaleString()}</span>
              </div>
            </motion.div>
          ))}
        </AnimatePresence>
      </div>

      {filtered.length === 0 && (
        <div className="text-center py-16 text-muted-foreground">
          <p className="text-lg">No leads found</p>
          <p className="text-sm mt-1">Try adjusting your search or filters</p>
        </div>
      )}

      {/* Modal Form */}
      <AnimatePresence>
        {showForm && editLead && (
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="fixed inset-0 bg-background/80 backdrop-blur-sm z-50 flex items-center justify-center p-4" onClick={closeForm}>
            <motion.div
              initial={{ opacity: 0, scale: 0.95, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 20 }}
              className="glass-card p-6 w-full max-w-lg max-h-[90vh] overflow-y-auto"
              onClick={e => e.stopPropagation()}
            >
              <div className="flex items-center justify-between mb-6">
                <h2 className="text-xl font-display font-bold">{editLead.id ? 'Edit Lead' : 'New Lead'}</h2>
                <button onClick={closeForm} className="p-2 rounded-lg hover:bg-secondary text-muted-foreground"><X className="w-5 h-5" /></button>
              </div>
              <div className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="text-xs font-medium text-muted-foreground block mb-1">Name *</label>
                    <input value={editLead.name || ''} onChange={e => setEditLead({ ...editLead, name: e.target.value })} className={inputClass} />
                  </div>
                  <div>
                    <label className="text-xs font-medium text-muted-foreground block mb-1">Email *</label>
                    <input type="email" value={editLead.email || ''} onChange={e => setEditLead({ ...editLead, email: e.target.value })} className={inputClass} />
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="text-xs font-medium text-muted-foreground block mb-1">Phone</label>
                    <input value={editLead.phone || ''} onChange={e => setEditLead({ ...editLead, phone: e.target.value })} className={inputClass} />
                  </div>
                  <div>
                    <label className="text-xs font-medium text-muted-foreground block mb-1">Company</label>
                    <input value={editLead.company || ''} onChange={e => setEditLead({ ...editLead, company: e.target.value })} className={inputClass} />
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="text-xs font-medium text-muted-foreground block mb-1">Source</label>
                    <select value={editLead.source || 'Website'} onChange={e => setEditLead({ ...editLead, source: e.target.value as LeadSource })} className={inputClass}>
                      {SOURCES.map(s => <option key={s} value={s}>{s}</option>)}
                    </select>
                  </div>
                  <div>
                    <label className="text-xs font-medium text-muted-foreground block mb-1">Lead Value ($)</label>
                    <input type="number" value={editLead.value || ''} onChange={e => setEditLead({ ...editLead, value: Number(e.target.value) })} className={inputClass} />
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="text-xs font-medium text-muted-foreground block mb-1">Stage</label>
                    <select value={editLead.stage || 'Prospect'} onChange={e => setEditLead({ ...editLead, stage: e.target.value as PipelineStage })} className={inputClass}>
                      {STAGES.map(s => <option key={s} value={s}>{s}</option>)}
                    </select>
                  </div>
                  <div>
                    <label className="text-xs font-medium text-muted-foreground block mb-1">Priority</label>
                    <select value={editLead.priority || 'Medium'} onChange={e => setEditLead({ ...editLead, priority: e.target.value as Lead['priority'] })} className={inputClass}>
                      {PRIORITIES.map(p => <option key={p} value={p}>{p}</option>)}
                    </select>
                  </div>
                </div>
                <div>
                  <label className="text-xs font-medium text-muted-foreground block mb-1">Notes</label>
                  <textarea rows={3} value={editLead.notes || ''} onChange={e => setEditLead({ ...editLead, notes: e.target.value })} className={inputClass} />
                </div>
                <button onClick={handleSave} className="w-full py-3 rounded-lg bg-gradient-to-r from-primary to-accent text-primary-foreground font-semibold hover:opacity-90 transition-opacity">
                  {editLead.id ? 'Update Lead' : 'Create Lead'}
                </button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};

export default LeadsPage;
