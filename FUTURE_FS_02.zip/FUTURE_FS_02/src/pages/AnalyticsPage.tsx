import { useMemo } from 'react';
import { motion } from 'framer-motion';
import { BarChart, Bar, PieChart, Pie, Cell, LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend } from 'recharts';
import { getLeads } from '@/lib/store';
import type { PipelineStage, LeadSource } from '@/lib/types';

const COLORS = {
  primary: '#7c3aed',
  accent: '#2dd4bf',
  info: '#0ea5e9',
  warning: '#f59e0b',
  success: '#22c55e',
  destructive: '#ef4444',
};

const PIE_COLORS = [COLORS.primary, COLORS.accent, COLORS.info, COLORS.warning, COLORS.success];

const AnalyticsPage = () => {
  const leads = useMemo(() => getLeads(), []);

  const totalLeads = leads.length;
  const wonLeads = leads.filter(l => l.stage === 'Won').length;
  const lostLeads = leads.filter(l => l.stage === 'Lost').length;
  const conversionRate = totalLeads > 0 ? ((wonLeads / totalLeads) * 100).toFixed(1) : '0';
  const totalValue = leads.reduce((s, l) => s + l.value, 0);
  const avgDealSize = totalLeads > 0 ? Math.round(totalValue / totalLeads) : 0;

  // By stage
  const stageData = (['Prospect', 'Contacted', 'Negotiation', 'Won', 'Lost'] as PipelineStage[]).map(stage => ({
    name: stage,
    count: leads.filter(l => l.stage === stage).length,
    value: leads.filter(l => l.stage === stage).reduce((s, l) => s + l.value, 0),
  }));

  // By source
  const sourceData = (['Website', 'LinkedIn', 'Referral', 'Ads'] as LeadSource[]).map(source => ({
    name: source,
    count: leads.filter(l => l.source === source).length,
  }));

  // Monthly (mock based on created dates)
  const monthlyData = useMemo(() => {
    const months: Record<string, number> = {};
    leads.forEach(l => {
      const m = new Date(l.createdAt).toLocaleString('default', { month: 'short' });
      months[m] = (months[m] || 0) + 1;
    });
    return Object.entries(months).map(([month, count]) => ({ month, count }));
  }, [leads]);

  const metricCards = [
    { label: 'Total Leads', value: totalLeads, color: 'text-primary' },
    { label: 'Won Deals', value: wonLeads, color: 'text-success' },
    { label: 'Conversion Rate', value: `${conversionRate}%`, color: 'text-accent' },
    { label: 'Pipeline Value', value: `$${(totalValue / 1000).toFixed(0)}k`, color: 'text-warning' },
    { label: 'Avg Deal Size', value: `$${avgDealSize.toLocaleString()}`, color: 'text-info' },
    { label: 'Lost Deals', value: lostLeads, color: 'text-destructive' },
  ];

  return (
    <div className="space-y-8 max-w-7xl mx-auto">
      <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }}>
        <h1 className="text-3xl font-display font-bold">Analytics</h1>
        <p className="text-muted-foreground mt-1">Performance insights and metrics</p>
      </motion.div>

      {/* Metric Cards */}
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
        {metricCards.map((m, i) => (
          <motion.div key={m.label} initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.05 }} className="glass-card p-4 text-center">
            <p className={`text-2xl font-display font-bold ${m.color}`}>{m.value}</p>
            <p className="text-xs text-muted-foreground mt-1">{m.label}</p>
          </motion.div>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Leads by Stage */}
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.2 }} className="glass-card p-6">
          <h3 className="font-display font-semibold mb-4">Leads by Stage</h3>
          <ResponsiveContainer width="100%" height={280}>
            <BarChart data={stageData}>
              <CartesianGrid strokeDasharray="3 3" stroke="hsl(230 20% 18%)" />
              <XAxis dataKey="name" tick={{ fill: 'hsl(215 20% 55%)', fontSize: 12 }} />
              <YAxis tick={{ fill: 'hsl(215 20% 55%)', fontSize: 12 }} />
              <Tooltip contentStyle={{ background: 'hsl(230 25% 10%)', border: '1px solid hsl(230 20% 18%)', borderRadius: '8px', color: 'hsl(210 40% 96%)' }} />
              <Bar dataKey="count" fill={COLORS.primary} radius={[6, 6, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </motion.div>

        {/* Leads by Source */}
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.3 }} className="glass-card p-6">
          <h3 className="font-display font-semibold mb-4">Leads by Source</h3>
          <ResponsiveContainer width="100%" height={280}>
            <PieChart>
              <Pie data={sourceData} cx="50%" cy="50%" innerRadius={60} outerRadius={100} paddingAngle={4} dataKey="count" label={({ name, count }) => `${name}: ${count}`}>
                {sourceData.map((_, i) => <Cell key={i} fill={PIE_COLORS[i % PIE_COLORS.length]} />)}
              </Pie>
              <Tooltip contentStyle={{ background: 'hsl(230 25% 10%)', border: '1px solid hsl(230 20% 18%)', borderRadius: '8px', color: 'hsl(210 40% 96%)' }} />
            </PieChart>
          </ResponsiveContainer>
        </motion.div>

        {/* Monthly Growth */}
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.4 }} className="glass-card p-6 lg:col-span-2">
          <h3 className="font-display font-semibold mb-4">Lead Growth</h3>
          <ResponsiveContainer width="100%" height={280}>
            <LineChart data={monthlyData}>
              <CartesianGrid strokeDasharray="3 3" stroke="hsl(230 20% 18%)" />
              <XAxis dataKey="month" tick={{ fill: 'hsl(215 20% 55%)', fontSize: 12 }} />
              <YAxis tick={{ fill: 'hsl(215 20% 55%)', fontSize: 12 }} />
              <Tooltip contentStyle={{ background: 'hsl(230 25% 10%)', border: '1px solid hsl(230 20% 18%)', borderRadius: '8px', color: 'hsl(210 40% 96%)' }} />
              <Line type="monotone" dataKey="count" stroke={COLORS.accent} strokeWidth={3} dot={{ fill: COLORS.accent, r: 5 }} />
            </LineChart>
          </ResponsiveContainer>
        </motion.div>

        {/* Pipeline Value by Stage */}
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.5 }} className="glass-card p-6 lg:col-span-2">
          <h3 className="font-display font-semibold mb-4">Pipeline Value by Stage</h3>
          <ResponsiveContainer width="100%" height={280}>
            <BarChart data={stageData}>
              <CartesianGrid strokeDasharray="3 3" stroke="hsl(230 20% 18%)" />
              <XAxis dataKey="name" tick={{ fill: 'hsl(215 20% 55%)', fontSize: 12 }} />
              <YAxis tick={{ fill: 'hsl(215 20% 55%)', fontSize: 12 }} tickFormatter={v => `$${(v/1000).toFixed(0)}k`} />
              <Tooltip contentStyle={{ background: 'hsl(230 25% 10%)', border: '1px solid hsl(230 20% 18%)', borderRadius: '8px', color: 'hsl(210 40% 96%)' }} formatter={(v: number) => [`$${v.toLocaleString()}`, 'Value']} />
              <Bar dataKey="value" fill={COLORS.accent} radius={[6, 6, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </motion.div>
      </div>
    </div>
  );
};

export default AnalyticsPage;
