# NEXUSFLOW – Relationship Intelligence CRM

> **Future Interns – Full Stack Development Internship | Task 2: Client Lead Management System**

A modern, fully functional CRM web application that visualizes client relationships, follow-ups, and deal progress through an interactive workflow-based interface.

**Live Demo:** [nexusflowintelligentcrm.lovable.app](https://nexusflowintelligentcrm.lovable.app)

---

## 📸 Screenshots

> Add screenshots of your running application here:
> - Login Page
> - Dashboard
> - Pipeline (Kanban Board)
> - Lead Detail Page
> - Analytics Dashboard
> - Follow-Ups Page

---

## 🚀 Features

### 1. Authentication System
- Admin login with credential validation
- Session persistence via localStorage
- Protected routes – unauthenticated users are redirected to login

### 2. Lead Capture Module
- Add leads with Name, Email, Phone, Company, Lead Source, Lead Value, and Notes
- Lead sources: Website, LinkedIn, Referral, Ads

### 3. Smart Lead Pipeline (Kanban Board)
- Visual drag-and-drop pipeline: **Prospect → Contacted → Negotiation → Won → Lost**
- Lead cards show quick info (company, value, health score)
- Stage changes are automatically logged in the activity timeline

### 4. Lead Details Page
- Full client profile with communication history
- Tabbed interface for Notes, Follow-ups, and Activity Timeline
- Health Score and Relationship Strength indicators

### 5. Follow-Up Intelligence System
- Schedule follow-ups with reminder dates
- Mark as completed
- Grouped view: Overdue, Upcoming, Completed

### 6. Activity Timeline
- Auto-logged events: Lead created, Email sent, Meeting scheduled, Stage changed, Deal won
- Chronological timeline per lead

### 7. Lead Search & Filters
- Search by Name, Company
- Filter by Status, Lead Source, Priority

### 8. Analytics Dashboard
- Total leads, Converted leads, Conversion rate
- Leads by source (Pie chart)
- Monthly growth (Bar chart)
- Pipeline distribution and revenue metrics

### 9. Notes System
- Attach unlimited notes to any lead
- Timestamped and deletable

### 10. CRUD Operations
- Full Create, Read, Update, Delete for all leads

### 11. Innovative CRM Features
- **Lead Health Score** (0-100): Auto-calculated based on stage progression and activity
- **Smart Priority Tags**: Low, Medium, High, Critical
- **Relationship Strength Indicator** (0-100): Visual gauge of client engagement

### 12. UI/UX
- Dark SaaS theme with glassmorphism cards
- Framer Motion animations throughout
- Gradient highlights and interactive lead cards
- Responsive design

---

## 🛠 Tech Stack

| Layer       | Technology                                      |
|-------------|------------------------------------------------|
| Frontend    | React 18, TypeScript, Vite                     |
| Styling     | Tailwind CSS, Glassmorphism, Framer Motion     |
| Charts      | Recharts                                        |
| UI Library  | shadcn/ui (Radix UI primitives)                |
| Routing     | React Router DOM v6                            |
| Data Layer  | localStorage (simulates MongoDB persistence)   |
| State       | React Hooks + TanStack React Query             |

---

## 📁 Folder Structure

```
FUTURE_FS_02/
├── public/
│   ├── placeholder.svg
│   └── robots.txt
├── src/
│   ├── assets/
│   ├── components/
│   │   ├── ui/              # shadcn/ui components
│   │   ├── AppShell.tsx      # Main layout with sidebar
│   │   └── NavLink.tsx       # Navigation link component
│   ├── hooks/
│   │   ├── use-mobile.tsx
│   │   └── use-toast.ts
│   ├── lib/
│   │   ├── store.ts          # Data layer (CRUD, auth, seed data)
│   │   ├── types.ts          # TypeScript interfaces
│   │   └── utils.ts          # Utility functions
│   ├── pages/
│   │   ├── AnalyticsPage.tsx  # Charts & metrics
│   │   ├── DashboardPage.tsx  # Overview dashboard
│   │   ├── FollowUpsPage.tsx  # Follow-up management
│   │   ├── LeadDetailPage.tsx # Individual lead view
│   │   ├── LeadsPage.tsx      # Lead list with search/filter
│   │   ├── LoginPage.tsx      # Authentication
│   │   ├── PipelinePage.tsx   # Kanban drag-and-drop
│   │   └── NotFound.tsx       # 404 page
│   ├── App.tsx
│   ├── App.css
│   ├── index.css
│   └── main.tsx
├── index.html
├── package.json
├── tailwind.config.ts
├── vite.config.ts
├── tsconfig.json
└── README.md
```

---

## ⚙️ Installation & Setup

### Prerequisites
- **Node.js** >= 18
- **npm** or **bun** package manager

### Steps

```bash
# 1. Clone the repository
git clone https://github.com/<your-username>/FUTURE_FS_02.git
cd FUTURE_FS_02

# 2. Install dependencies
npm install

# 3. Start the development server
npm run dev

# 4. Open in browser
# Visit http://localhost:8080
```

### Login Credentials
| Field    | Value                 |
|----------|-----------------------|
| Email    | admin@nexusflow.io    |
| Password | admin123              |

---

## 🌐 Deployment

### Frontend → Vercel
1. Push code to GitHub
2. Go to [vercel.com](https://vercel.com) → Import project
3. Framework: **Vite**
4. Build command: `npm run build`
5. Output directory: `dist`

### Alternative: Netlify
1. Build command: `npm run build`
2. Publish directory: `dist`

### Database → MongoDB Atlas (Future Enhancement)
- Create a free cluster at [mongodb.com/atlas](https://www.mongodb.com/atlas)
- Replace localStorage calls with MongoDB API endpoints

### Backend → Render (Future Enhancement)
- Deploy Express.js server on [render.com](https://render.com)
- Connect to MongoDB Atlas

---

## 🔮 Future Improvements

- [ ] Backend with Node.js + Express.js + MongoDB
- [ ] JWT-based authentication with refresh tokens
- [ ] Email notifications for follow-up reminders
- [ ] Lead import/export (CSV)
- [ ] Multi-user support with role-based access
- [ ] AI-powered lead scoring
- [ ] Integration with email providers (Gmail, Outlook)
- [ ] Mobile app version

---

## 📄 Environment Variables (for future backend)

```env
# .env.example
PORT=5000
MONGODB_URI=mongodb+srv://<username>:<password>@cluster.mongodb.net/nexusflow
JWT_SECRET=your_jwt_secret_key
```

---

## 👨‍💻 Author

**Your Name**
- Future Interns – Full Stack Development Intern
- Task 2: Client Lead Management System

---

## 📝 License

This project is built as part of the Future Interns internship program.
